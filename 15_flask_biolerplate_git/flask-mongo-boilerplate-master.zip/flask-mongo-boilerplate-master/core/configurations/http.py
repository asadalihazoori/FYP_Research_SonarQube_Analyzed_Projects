from uuid import uuid4

SECRET_KEY = str(uuid4())
LOGGER_NAME = 'http'

HOST = 'localhost'
PORT = 5000