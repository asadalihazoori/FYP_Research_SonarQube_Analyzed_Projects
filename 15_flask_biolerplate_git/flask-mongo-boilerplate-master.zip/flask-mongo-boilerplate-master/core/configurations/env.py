# TODO: Change working directory
import os

WORKING_DIRECTORY = os.getcwd()
DEBUG_MODE = True
DEVELOP_MODE = True
