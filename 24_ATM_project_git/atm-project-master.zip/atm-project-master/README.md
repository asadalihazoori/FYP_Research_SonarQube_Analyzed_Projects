# ATM Project
This project makes it easy to manage your ATM.
## Manage Your ATM Accounts and transactions
Now you can get info about all the process that happend
<li class="downloads"><a href="{{ site.github.zip_url }}">ZIP</a></li>
<li class="downloads"><a href="{{ site.github.tar_url }}">TAR</a></li>
