set -e
set -x

sudo apt-get install openssl build-essential xorg libssl-dev python-qt4