set -e
set -x

python tests/test.py
