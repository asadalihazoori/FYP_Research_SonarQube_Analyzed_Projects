# Python-Media-Player
This is a simple music player written in Python With Tkinter and Other Useful Module. I wrote this project just 
for practise and fun purpose. if you are also new to python and want to practise your skills . then you can use this
python repo and your Project. You can Upgrade the features of this Music Player

### First Screenshot
![Screenshot](src/test.png?raw=true "Screen1")

### Second Screenshot
![Screenshot](src/test1.png?raw=true "Screen2")

###  Author Details
```
    Suraj Singh
    Admin
    S.S.B Group
    surajsinghbisht054@gmail.com
    http://www.bitforestinfo.com
```


# Development.


Want to Contribute? Great!


There Are 2 Methods.

1. Pull Request ( Github Account Required ).

2. Through Email.


### 1. Pull Request ( Github A/c Required ). 

1. Fork it!

2. Create your feature branch: `git checkout -b my-new-feature`

3. Commit your changes: `git commit -am 'Add some feature'`

4. Push to the branch: `git push origin my-new-feature`

5. Submit a pull request :D



### 2. Through Email.

1. Send Your Updated Version On My Email.

- surajsinghbisht054@gmail.com


-----

## Contributing

See [CONTRIBUTING](/CONTRIBUTING.md).

----

## License

Apache License



